**Documentation**

A great place to start is at Pluralsight! Watch the course titled "MVVM Light Fundamentals" available at [http://pluralsight.com/training/Courses/TableOfContents/mvvm-light-toolkit-fundamentals](http://pluralsight.com/training/Courses/TableOfContents/mvvm-light-toolkit-fundamentals)

![](Documentation_http://www.mvvmlight.net/resources/Logo/MvvmLightAtPluralsight_550x146.png)

See the videos and articles available at [http://www.mvvmlight.net/doc/](http://www.mvvmlight.net/doc/)

**Source code documentation**

The source code documentation is available at [http://www.mvvmlight.net/help/](http://www.mvvmlight.net/help/)

**Building the code**

In order to get the latest source code from the Source Code section, build it, unit test it, and get the latest DLLs installed, check this article:
[http://www.mvvmlight.net/building/](http://www.mvvmlight.net/building/)

**Installing the binaries with NuGet**

You can add MVVM Light to an existing Windows Presentation Foundation, Silverlight, Windows Store or Windows Phone project with the help of the NuGet package manager. For more information, visit [http://www.mvvmlight.net/installing/nuget/](http://www.mvvmlight.net/installing/nuget/) 

**Installing the full toolkit (binaries, templates, snippets)**

See this page to install the full MVVM Light Toolkit : [http://www.mvvmlight.net/installing/](http://www.mvvmlight.net/installing/)

**Creating your first application**

To create an application in Visual Studio: [http://www.mvvmlight.net/creating/](http://www.mvvmlight.net/creating/).


# Project Description
The main purpose of the toolkit is to accelerate the creation and development of MVVM applications in WPF, Silverlight, Windows Store, Windows Phone and Xamarin

# Get started
More information about the MVVM Light Toolkit can be found on [ http://www.mvvmlight.net]( http://www.mvvmlight.net).

# Documentation
See [http://www.mvvmlight.net/doc](http://www.mvvmlight.net/doc)

# Donate
If you are so enclined, you can [donate to MVVM Light Toolkit](http://www.mvvmlight.net/donate).
Or, if you prefer, you can pay me a beer next time we're in the same vicinity. Really, it is OK too :)

# Latest news:
The latest news about MVVM Light are available from the MVVM feed on my blog at [http://blog.galasoft.ch/posts/category/mvvm/](http://blog.galasoft.ch/posts/category/mvvm/).